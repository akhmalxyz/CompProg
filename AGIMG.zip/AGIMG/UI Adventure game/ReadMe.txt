It is advisable to play this game on PyGame as the GUI has not been tested on other platforms
